<?php include_once "header.php" ?>

<h1>Links</h1>
<p>Go see some other cool stuff</p>

<?php include_once "footer.php" ?>