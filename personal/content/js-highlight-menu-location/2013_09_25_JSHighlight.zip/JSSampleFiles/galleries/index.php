<?php include_once "../header.php" ?>

<h1>Photo Galleries</h1>
<p>All the pretty pictures!</p>

<?php include_once "../footer.php" ?>