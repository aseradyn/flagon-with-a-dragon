<?php include_once "header.php" ?>



<h1>Home Page</h1>
<p>This is the home page</p>

<?php include_once "footer.php" ?>