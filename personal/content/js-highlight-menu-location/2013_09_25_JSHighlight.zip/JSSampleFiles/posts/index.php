<?php include_once "../header.php" ?>

<h1>Blog Posts</h1>
<p>Here's a list of my recent blog posts</p>

<?php include_once "../footer.php" ?>